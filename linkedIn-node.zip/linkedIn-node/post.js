const axios = require("axios");

module.exports = {
  async postAchievement(accessToken, message) {
    try {
      // 1. Get your LinkedIn URN
      const profileRes = await axios.get("https://api.linkedin.com/v2/me", {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'X-Restli-Protocol-Version': '2.0.0',
        },
      });

      console.log(">>>>>profile response", profileRes.data)
      const urn = profileRes.data.id;

    //   // 2. Post content
      const postRes = await axios.post(
        "https://api.linkedin.com/v2/ugcPosts",
        {
          author: `urn:li:person:${urn}`,
          lifecycleState: "PUBLISHED",
          specificContent: {
            "com.linkedin.ugc.ShareContent": {
              shareCommentary: {
                text: "Hey!! Checking my api endpoint",
              },
              shareMediaCategory: "NONE",
            },
          },
          visibility: {
            "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC",
          },
        },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
            "X-Restli-Protocol-Version": "2.0.0",
          },
        }
      );

      console.log(">>>postRes", postRes);
    //   console.log("Posted successfully!", postRes.data);
    } catch (err) {
      console.error("Post error:", err.response?.data || err.message);
    }
  },

};


const express = require("express");
const axios = require("axios");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(express.json());

const ACCESS_TOKEN = process.env.LINKEDIN_ACCESS_TOKEN; // or pass it from req.body

app.post("/post-linkedIn", async (req, res) => {
  try {
    // 1. Get user URN
    const profileRes = await axios.get("https://api.linkedin.com/v2/userinfo", {
      headers: { Authorization: `Bearer ${ACCESS_TOKEN}` },
    });

    const urn = `urn:li:person:${profileRes.data.sub}`;
    console.log("User URN:", urn);

    // 2. Register upload
    const registerRes = await axios.post(
      "https://api.linkedin.com/v2/assets?action=registerUpload",
      {
        registerUploadRequest: {
          owner: urn,
          recipes: ["urn:li:digitalmediaRecipe:feedshare-image"],
          serviceRelationships: [
            {
              relationshipType: "OWNER",
              identifier: "urn:li:userGeneratedContent",
            },
          ],
        },
      },
      {
        headers: {
          Authorization: `Bearer ${ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
      }
    );

    const uploadUrl =
      registerRes.data.value.uploadMechanism["com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest"].uploadUrl;
    const asset = registerRes.data.value.asset;
    console.log("Upload URL:", uploadUrl);
    console.log("Asset URN:", asset);

    // 3. Upload image
    const imagePath = path.join(__dirname, "your-image.jpg"); // Replace with your image path
    const imageData = fs.readFileSync(imagePath);

    await axios.put(uploadUrl, imageData, {
      headers: {
        "Content-Type": "image/jpeg",
      },
    });
    console.log("✅ Image uploaded");

    // 4. Create UGC post with image
    const message = `🚀 Just launched a new project! ${new Date().toISOString()}`;
    const postBody = {
      author: urn,
      lifecycleState: "PUBLISHED",
      specificContent: {
        "com.linkedin.ugc.ShareContent": {
          shareCommentary: {
            text: message,
          },
          shareMediaCategory: "IMAGE",
          media: [
            {
              status: "READY",
              media: asset,
            },
          ],
        },
      },
      visibility: {
        "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC",
      },
    };

    const postRes = await axios.post(
      "https://api.linkedin.com/v2/ugcPosts",
      postBody,
      {
        headers: {
          Authorization: `Bearer ${ACCESS_TOKEN}`,
          "Content-Type": "application/json",
          "X-Restli-Protocol-Version": "2.0.0",
        },
      }
    );

    console.log("✅ Post created:", postRes.data);
    res.send("✅ Image post published to LinkedIn!");
  } catch (err) {
    console.error("❌ Post error:", err.response?.data || err.message);
    res.status(500).send("❌ Failed to post image to LinkedIn.");
  }
});

 //   const accessToken = req.body.accessToken;

  //   try {
  //     // 1. Get user URN
  //     console.log("beforore postAchievement");
  //     const profileRes = await axios.get("https://api.linkedin.com/v2/userinfo", {
  //       headers: { Authorization: `Bearer ${ACCESS_TOKEN}` },
  //     });

  //     const urn = profileRes.data.sub;
  //     console.log("------>", urn);
  //     const message = `API TEST1 ---- 🚀 Just launched a new project! ${new Date().toISOString()}`;

  //     // 2. Post content
  //     const postBody = {
  //       author: `urn:li:person:${urn}`,
  //       lifecycleState: "PUBLISHED",
  //       specificContent: {
  //         "com.linkedin.ugc.ShareContent": {
  //           shareCommentary: { text: message },
  //           shareMediaCategory: "NONE",
  //         },
  //       },
  //       visibility: { "com.linkedin.ugc.MemberNetworkVisibility": "PUBLIC" },
  //     };

  //     const postRes = await axios.post(
  //       "https://api.linkedin.com/v2/ugcPosts",
  //       postBody,
  //       {
  //         headers: {
  //           Authorization: `Bearer ${ACCESS_TOKEN}`,
  //           "Content-Type": "application/json",
  //           "X-Restli-Protocol-Version": "2.0.0",
  //         },
  //       }
  //     );
  //     console.log("postRes", postRes);
  //     res.send("✅ Achievement posted successfully!");
  //   } catch (err) {
  //     console.error("Post error:", err.response?.data || err.message);
  //     res.status(500).send("❌ Failed to post achievement.");
  //   }